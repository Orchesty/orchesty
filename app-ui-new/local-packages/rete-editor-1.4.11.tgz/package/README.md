# Rete Editor Library

A modern, configurable node-based visual editor built with Vue 3, Rete.js, TypeScript, and TailwindCSS.

## Features

- 🧠 **Powerful Node Editor** - Built on Rete.js for flexible node-based workflows
- 🎯 **Configurable Modes** - Edit and readonly modes with granular feature control
- 🏷️ **Custom Labels** - Add dynamic fields and action buttons to any node type
- 🎛️ **Multi-Instance Support** - Multiple isolated editors on the same page
- 📊 **JSON Import/Export** - Full workflow serialization
- ⚡ **Vue 3 + TypeScript** - Modern composition API with full type safety
- 🎨 **TailwindCSS Styling** - Customizable with utility-first CSS
- 🌙 **Dark Mode** - Built-in theme support
- 📐 **Grid Snapping** - Configurable grid display and alignment
- ⌨️ **Keyboard Shortcuts** - Intuitive navigation and editing
- 🚀 **Production Ready** - Optimized build with tree-shaking

## Installation

### From npm (when published)

```bash
npm install @your-org/rete-editor
```

### From Local Package

```bash
npm install ./path/to/rete-editor-1.0.0.tgz
```

### Prerequisites

This library requires the following dependencies in your application:

**Vue 3:**
```bash
npm install vue@^3.4.0
```

**Tailwind CSS:**
```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init
```

Make sure your `tailwind.config.js` includes the library's components in the content paths:

```js
export default {
  content: [
    './src/**/*.{vue,js,ts,jsx,tsx}',
    './node_modules/rete-editor/**/*.{js,vue}' // Add this line
  ],
  darkMode: 'class', // Required for dark mode support
  // ... rest of config
}
```

All other dependencies (Rete.js plugins) are bundled with the library.

## Setup

### Import CSS

Import the editor's custom CSS styles in your application entry point:

```typescript
// main.ts
import '@your-org/rete-editor/style.css'
```

The editor uses Tailwind CSS utility classes from your application. Make sure:
1. Tailwind CSS is configured (see Prerequisites above)
2. The library path is included in Tailwind's `content` array
3. Your app's CSS includes Tailwind directives (`@tailwind base; @tailwind components; @tailwind utilities;`)

The editor will work with your existing Tailwind/Flowbite dark mode toggle automatically.

### Dark Mode

The editor supports class-based dark mode (Tailwind standard):
- Add `dark` class to `<html>` or `<body>` element to enable dark mode
- Works automatically with Flowbite and other Tailwind-based UI frameworks

```typescript
// Example with Flowbite
document.documentElement.classList.toggle('dark')
```

## Quick Start

### Basic Usage

```vue
<template>
  <Editor :config="editorConfig" @ready="onReady" />
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { ReteEditorKit, type EditorCore } from '@your-org/rete-editor'

// Destructure the editor kit
const { Editor, createConfig } = ReteEditorKit

// Create configuration with mode preset
const editorConfig = createConfig({
  mode: 'edit'  // or 'readonly'
})

const editorCore = ref<EditorCore>()

const onReady = (editor: EditorCore) => {
  editorCore.value = editor
  console.log('Editor ready!')
}
</script>
```

### Load Existing Workflow

```vue
<script setup lang="ts">
import { ReteEditorKit, type EditorCore } from '@your-org/rete-editor'
import workflowData from './workflow.json'

const { Editor, createConfig } = ReteEditorKit

const config = createConfig({
  mode: 'readonly',
  canvasHeight: '600px'
})

const onReady = async (editor: EditorCore) => {
  // Import workflow from JSON
  await editor.importFromJSON(JSON.stringify(workflowData))
  
  // Fit all nodes in view
  editor.zoomToFit()
}
</script>
```

## Library Structure

```
@your-org/rete-editor/
├── core/                    # Core editor classes
│   ├── EditorCore.ts        # Main editor API
│   ├── EditorConfig.ts      # Configuration factory
│   ├── PluginManager.ts     # Rete plugin management
│   ├── SelectionManager.ts  # Node selection state
│   ├── KeyboardManager.ts   # Keyboard event handling
│   └── LabelCustomization.ts # Label customization types
├── nodes/                   # Node system
│   ├── FlowNode.ts          # Workflow nodes
│   ├── AnnotationNode.ts    # Annotation nodes
│   ├── FlowConnection.ts    # Node connections
│   └── NodeFactory.ts       # Node creation
├── data/                    # Static data
│   └── actions.ts           # Available actions for nodes
├── serialization/           # Import/Export
│   ├── Serializer.ts        # JSON serialization
│   └── types.ts             # Serialization types
├── ui/                      # Vue components
│   ├── ReteEditorWrapper.vue  # Main wrapper component
│   ├── nodes/               # Node view components
│   ├── controls/            # Control components
│   └── sockets/             # Socket components
└── index.ts                 # Public API exports
```

## Usage Examples

### Simple Import with ReteEditorKit

The library provides a convenient `ReteEditorKit` for easy, single-import usage:

```vue
<template>
  <Editor :config="editorConfig" @ready="onReady" @node-selected="onNodeSelected" />
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { ReteEditorKit, type EditorCore } from '@your-org/rete-editor'

// Destructure the editor kit
const { Editor, createConfig } = ReteEditorKit

// Create configuration - just specify the mode!
const editorConfig = createConfig({
  mode: 'edit'  // or 'readonly'
})

const editorCore = ref<EditorCore>()

const onReady = (editor: EditorCore) => {
  editorCore.value = editor
}

const onNodeSelected = (data: any) => {
  console.log('Node selected:', data)
}
</script>
```

### Programmatic Usage

```typescript
import { ReteEditorKit } from '@your-org/rete-editor'

const { createConfig } = ReteEditorKit

// Create configuration
const config = createConfig({
  mode: 'edit'
})

// Or use advanced imports for programmatic control
import { EditorCore } from '@your-org/rete-editor'

const editorCore = new EditorCore(config)
await editorCore.initialize(containerElement)

// Add nodes
const eventNode = await editorCore.addFlowNode('Webhook', 'circle', { x: 100, y: 100 })
const connectorNode = await editorCore.addFlowNode('Connector', 'rectangle', { x: 400, y: 100 })

// Export/Import
const json = editorCore.exportToJSON()
await editorCore.importFromJSON(json)
```

## Configuration Options

### Editor Modes

The editor supports two fixed modes with preset configurations:

- **`edit`** - Full editing capabilities
  - Context menu, add node button, multi-select, history, node label, zoom controls
  - Grid enabled with snap-to-grid (20px)

- **`readonly`** - View-only mode
  - All editing features disabled
  - Multi-select enabled (for viewing selected nodes)
  - Node label and zoom controls enabled
  - Grid enabled with snap-to-grid (20px)

```typescript
// Simple mode selection
const config = createConfig({ mode: 'readonly' })
```

### Canvas Height

Customize the editor canvas height (defaults to 640px):

```typescript
const config = createConfig({
  mode: 'edit',
  canvasHeight: '800px'  // Any valid CSS height value
})
```

### Label Customization

Add custom fields and action buttons to node labels based on node type:

```typescript
import type { LabelCustomizationMap } from '@your-org/rete-editor'

const labelCustomization: LabelCustomizationMap = {
  // Customize labels for "Cron" node type
  Cron: {
    // Add custom fields (displayed as "label: value")
    getFields: () => {
      return [
        { label: 'Crontab', value: '*/15 * * * *' },
        { label: 'Next run', value: new Date(Date.now() + 900000).toLocaleString() }
      ]
    },

    // Add action buttons below the label
    getActions: () => {
      return [
        {
          id: 'toggle',
          icon: '<path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>',  // SVG path
          tooltip: 'Enable/Disable',
          onClick: async (node: any) => {
            console.log('Toggle:', node)
            // Your action logic here
          }
        },
        {
          id: 'run',
          icon: '<path d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/>',
          tooltip: 'Run Now',
          onClick: async (node: any) => {
            console.log('Run:', node)
          }
        }
      ]
    },

    // Optional: completely override the default label
    getCustomLabel: (node: any) => {
      return `<strong>${node.name}</strong> (Custom)`
    }
  }
}

// Apply customization to editor
const config = createConfig({
  mode: 'edit',
  labelCustomization  // Add custom label configuration
})
```

**Label Display Format:**
- Main label and custom fields appear in a single line
- Separated by semicolons (`;`)
- Each field pair (`label: value`) stays together when wrapping
- Action buttons appear below the label

Example output:
```
Cron: 15 min cron; Crontab: */15 * * * *; Next run: 12/24/2025, 3:45:00 PM
[Enable/Disable] [Run Now] [Settings]
```

### Multiple Editor Instances

The library supports multiple editor instances on the same page with isolated keyboard shortcuts:

```vue
<template>
  <div>
    <!-- Readonly instance -->
    <Editor :config="readonlyConfig" />
    
    <!-- Edit instance -->
    <Editor :config="editConfig" />
  </div>
</template>

<script setup lang="ts">
import { ReteEditorKit } from '@your-org/rete-editor'

const { Editor, createConfig } = ReteEditorKit

const readonlyConfig = createConfig({
  mode: 'readonly'
})

const editConfig = createConfig({
  mode: 'edit'
})
</script>
```

**Isolation Features:**
- Each editor has its own keyboard event listener scoped to its container
- Backspace/Delete only affects the focused editor
- Escape key only cancels insert mode in the focused editor
- No conflicts between multiple instances

### Disabled State & Reactive Labels

Event nodes (circle shape) can be disabled for visual indication. This is a runtime state typically used in readonly mode.

#### Setting Disabled Nodes

```typescript
const onReady = async (editor: EditorCore) => {
  // Load workflow
  await editor.importFromJSON(workflowJson)
  
  // Set disabled nodes from backend
  const disabledNodeIds = await fetchDisabledNodesFromAPI()
  editor.setDisabledNodes(disabledNodeIds)
}
```

#### Toggle Single Node

```typescript
// Toggle disabled state for one node
const toggleNode = (nodeId: string) => {
  const newState = editorCore.value?.toggleNodeDisabled(nodeId)
  console.log('Node is now:', newState ? 'disabled' : 'enabled')
}
```

#### Visual Appearance

Disabled nodes are rendered with:
- **Light mode**: Grayscale filter + 50% opacity
- **Dark mode**: Grayscale + darkened (70% brightness) + 60% opacity
- Non-interactive cursor

#### Reactive Label Updates

Labels are reactive and can be refreshed when backend data changes:

```typescript
// In labelCustomization
const labelCustomization: LabelCustomizationMap = {
  Cron: {
    getFields: (node) => {
      // This will be called again when refreshNodeLabel is triggered
      const cronNode = node as FlowNode & { 
        cronExpression?: string
        nextRun?: Date
        status?: string
      }
      
      return [
        { label: 'Crontab', value: cronNode.cronExpression || 'N/A' },
        { label: 'Next run', value: cronNode.nextRun?.toLocaleString() || 'N/A' },
        { label: 'Status', value: cronNode.disabled ? 'Disabled' : cronNode.status || 'Active' }
      ]
    },
    getActions: (node) => [
      {
        id: 'toggle',
        icon: '...',
        tooltip: node.disabled ? 'Enable' : 'Disable',
        onClick: async (node) => {
          await apiToggleCron(node.id)
          editorCore.value?.toggleNodeDisabled(node.id)
        }
      }
    ]
  }
}

// When backend data changes
const updateCronExpression = async (nodeId: string, newExpression: string) => {
  const node = editorCore.value?.getNode(nodeId)
  if (node instanceof FlowNode) {
    node.cronExpression = newExpression  // Update node property
    editorCore.value?.refreshNodeLabel(nodeId)  // Trigger label refresh
  }
}

// When cron starts running
const onCronRunning = (nodeId: string) => {
  const node = editorCore.value?.getNode(nodeId)
  if (node instanceof FlowNode) {
    node.status = 'running'
    editorCore.value?.refreshNodeLabel(nodeId)  // Label will show new status
  }
}
```

#### Complete Example with WebSocket Updates

```vue
<template>
  <Editor :config="config" @ready="onReady" />
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { ReteEditorKit, type EditorCore, FlowNode } from '@your-org/rete-editor'

const { Editor, createConfig } = ReteEditorKit

const config = createConfig({
  mode: 'readonly',
  labelCustomization: {
    Cron: {
      getFields: (node) => {
        // Reactive - called again when refreshNodeLabel() is triggered
        const cronNode = node as FlowNode & { 
          cronExpression?: string
          nextRun?: Date
          status?: string
        }
        
        return [
          { label: 'Crontab', value: cronNode.cronExpression || 'N/A' },
          { label: 'Next run', value: cronNode.nextRun?.toLocaleString() || 'N/A' },
          { label: 'Status', value: cronNode.disabled ? 'Disabled' : cronNode.status || 'Active' }
        ]
      },
      getActions: (node) => [
        {
          id: 'toggle',
          icon: '...',
          tooltip: node.disabled ? 'Enable' : 'Disable',
          onClick: async (node) => {
            await apiToggleCron(node.id)
            editorCore.value?.toggleNodeDisabled(node.id)
          }
        }
      ]
    }
  }
})

const editorCore = ref<EditorCore>()

const onReady = async (editor: EditorCore) => {
  editorCore.value = editor
  
  // Load workflow
  await editor.importFromJSON(workflowJson)
  
  // Set disabled nodes from backend
  const disabledIds = await fetchDisabledNodes()
  editor.setDisabledNodes(disabledIds)
  
  // Listen to backend updates via WebSocket
  backendWebSocket.on('cron-updated', (data) => {
    const node = editor.getNode(data.nodeId)
    if (node instanceof FlowNode) {
      node.cronExpression = data.newExpression
      node.nextRun = new Date(data.nextRun)
      editor.refreshNodeLabel(data.nodeId)
    }
  })
}
</script>
```

**Important Notes:**
- Disabled state is NOT serialized (runtime only)
- Only event nodes (circle shape) can be disabled
- Label refresh triggers re-computation of `getFields()` and `getActions()`
- Typically used in readonly mode for status visualization

### Complete Configuration Example

```typescript
import { ReteEditorKit, type LabelCustomizationMap } from '@your-org/rete-editor'

const { createConfig } = ReteEditorKit

// Define label customization for dynamic data from API
const labelCustomization: LabelCustomizationMap = {
  Cron: {
    getFields: (node) => [
      { label: 'Crontab', value: node.cronExpression },
      { label: 'Next run', value: calculateNextRun(node.cronExpression) }
    ],
    getActions: (node) => [
      {
        id: 'toggle',
        icon: '<path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>',
        tooltip: node.enabled ? 'Disable' : 'Enable',
        onClick: async (node) => {
          await apiToggleCron(node.id)
        }
      }
    ]
  }
}

// Complete configuration with all optional parameters
const config = createConfig({
  mode: 'edit',                      // Required: 'edit' | 'readonly'
  canvasHeight: '640px',             // Optional: CSS height value
  labelCustomization                 // Optional: custom labels and actions
})
```

## API Reference

### EditorCore

Main class for interacting with the editor.

**Methods:**
- `initialize(container: HTMLElement)` - Initialize the editor
- `addFlowNode(label, shape, position?)` - Add a workflow node
- `addAnnotationNode(text?, position?)` - Add an annotation
- `removeNode(nodeId)` - Remove a node
- `getNode(nodeId)` - Get node by ID
- `getNodes()` - Get all nodes
- `addConnection(sourceId, targetId)` - Connect two nodes
- `removeConnection(connectionId)` - Remove a connection
- `clear()` - Clear the editor
- `exportToJSON()` - Export graph as JSON string
- `exportGraph()` - Export graph as object
- `importFromJSON(json)` - Import graph from JSON string
- `importGraph(graph)` - Import graph from object
- `zoomToFit()` - Fit all nodes in view
- `zoomIn()` - Zoom in
- `zoomOut()` - Zoom out
- `setDisabledNodes(nodeIds: string[])` - Set disabled state for event nodes
- `toggleNodeDisabled(nodeId: string)` - Toggle disabled state for a single event node
- `refreshNodeLabel(nodeId: string)` - Refresh label for a specific node
- `refreshAllLabels()` - Refresh all node labels
- `on(event, callback)` - Subscribe to events
- `destroy()` - Cleanup and destroy

### Label Customization Types

**LabelField:**
```typescript
interface LabelField {
  label: string   // Field label (e.g., "Crontab")
  value: string   // Field value (e.g., "*/15 * * * *")
}
```

**LabelAction:**
```typescript
interface LabelAction {
  id: string                              // Unique action identifier
  icon: string                            // SVG path data for icon
  tooltip: string                         // Tooltip text
  onClick: (node: any) => void | Promise<void>  // Callback when clicked
}
```

**CustomLabelConfig:**
```typescript
interface CustomLabelConfig {
  getFields?: (node: any) => LabelField[]        // Get custom fields
  getActions?: (node: any) => LabelAction[]      // Get action buttons
  getCustomLabel?: (node: any) => string | null  // Override default label
}
```

**LabelCustomizationMap:**
```typescript
type LabelCustomizationMap = Record<string, CustomLabelConfig>
// Key = node baseLabel (e.g., "Cron", "Event", "Connector")
```

### ReteEditorKit

Convenient object for single-import usage:

```typescript
const ReteEditorKit = {
  Editor: ReteEditorWrapper,          // Main editor component
  createConfig: createEditorConfig,   // Configuration factory
  EditorMode                          // Mode enum/types
}
```

### Editor Events

The editor component emits the following events:

**@ready** - Emitted when editor is initialized
```typescript
@ready="(editor: EditorCore) => { /* editor is ready */ }"
```

**@node-added** - Emitted when a node is added
```typescript
@node-added="(node: any) => { /* node added */ }"
```

**@node-removed** - Emitted when a node is removed
```typescript
@node-removed="(nodeId: string) => { /* node removed */ }"
```

**@node-selected** - Emitted when a node is selected
```typescript
@node-selected="(data: { nodeId: string }) => { /* node selected */ }"
```

### Keyboard Shortcuts

**Edit Mode:**
- `Backspace/Delete` - Delete selected node(s)
- `Escape` - Cancel insert mode
- `Shift + Click` - Multi-select nodes

**Readonly Mode:**
- Keyboard editing disabled
- Navigation and zoom still available

## Common Use Cases

### 1. Simple Readonly Viewer

Display a workflow without editing capabilities:

```vue
<template>
  <Editor :config="config" @ready="onReady" />
</template>

<script setup lang="ts">
import { ReteEditorKit, type EditorCore } from '@your-org/rete-editor'
import workflowData from './workflow.json'

const { Editor, createConfig } = ReteEditorKit

const config = createConfig({
  mode: 'readonly',
  canvasHeight: '600px'
})

const onReady = async (editor: EditorCore) => {
  await editor.importFromJSON(JSON.stringify(workflowData))
}
</script>
```

### 2. Full-Featured Editor

Edit mode with all features enabled:

```vue
<template>
  <div>
    <Editor :config="config" @ready="onReady" />
    
    <div class="mt-4">
      <button @click="handleExport">Export</button>
      <button @click="handleClear">Clear</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { ReteEditorKit, type EditorCore } from '@your-org/rete-editor'

const { Editor, createConfig } = ReteEditorKit

const config = createConfig({
  mode: 'edit'
})

const editor = ref<EditorCore>()

const onReady = (editorInstance: EditorCore) => {
  editor.value = editorInstance
}

const handleExport = () => {
  const json = editor.value?.exportToJSON()
  console.log('Exported:', json)
}

const handleClear = () => {
  editor.value?.clear()
}
</script>
```

### 3. Cron Event Monitor (with Label Customization)

Display Cron events with real-time information and actions:

```typescript
import type { LabelCustomizationMap } from '@your-org/rete-editor'

const labelCustomization: LabelCustomizationMap = {
  Cron: {
    getFields: (node) => {
      // Calculate next run time based on cron expression
      const nextRun = calculateNextRun(node.cronExpression)
      
      return [
        { label: 'Crontab', value: node.cronExpression },
        { label: 'Next run', value: nextRun.toLocaleString() },
        { label: 'Status', value: node.enabled ? 'Enabled' : 'Disabled' }
      ]
    },
    
    getActions: (node) => [
      {
        id: 'toggle',
        icon: '<path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>',
        tooltip: node.enabled ? 'Disable' : 'Enable',
        onClick: async (node) => {
          await toggleCronJob(node.id)
          // Refresh editor to update label
        }
      },
      {
        id: 'run',
        icon: '<path d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/>',
        tooltip: 'Run Now',
        onClick: async (node) => {
          await triggerCronJob(node.id)
        }
      }
    ]
  }
}

const config = createConfig({
  mode: 'readonly',
  labelCustomization
})
```

### 4. Side-by-Side Comparison

Display two workflows side by side for comparison:

```vue
<template>
  <div class="grid grid-cols-2 gap-4">
    <div>
      <h3>Version 1</h3>
      <Editor :config="config1" @ready="onReady1" />
    </div>
    <div>
      <h3>Version 2</h3>
      <Editor :config="config2" @ready="onReady2" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ReteEditorKit, type EditorCore } from '@your-org/rete-editor'
import workflow1 from './workflow-v1.json'
import workflow2 from './workflow-v2.json'

const { Editor, createConfig } = ReteEditorKit

const config1 = createConfig({
  mode: 'readonly',
  canvasHeight: '500px'
})

const config2 = createConfig({
  mode: 'readonly',
  canvasHeight: '500px'
})

const onReady1 = async (editor: EditorCore) => {
  await editor.importFromJSON(JSON.stringify(workflow1))
}

const onReady2 = async (editor: EditorCore) => {
  await editor.importFromJSON(JSON.stringify(workflow2))
}
</script>
```

## Tips & Best Practices

1. **Multiple Instances**: Each editor instance is fully isolated with its own keyboard handling. You can safely have multiple editors on the same page.

2. **Label Customization**: Use `getFields()` for dynamic data from your backend API and `getActions()` for interactive buttons. Keep field values concise as they appear inline.

3. **Mode Selection**: Choose `'edit'` for full editing capabilities or `'readonly'` for view-only mode. All features (grid, theme, enabled features) are preset and optimized for each mode.

4. **Performance**: The editor is optimized for workflows with 100+ nodes. For readonly mode, use it when editing is not needed to prevent accidental modifications.

5. **Event Handling**: Subscribe to `@ready` before calling any editor methods. Use `@node-selected` to sync external UI with editor state and fetch additional data from your API.

## TypeScript Support

The library is written in TypeScript and provides full type definitions out of the box. Import types as needed:

```typescript
import type {
  EditorCore,
  EditorConfig,
  LabelCustomizationMap,
  LabelField,
  LabelAction,
  EditorMode
} from '@your-org/rete-editor'
```

## Troubleshooting

### Styles Not Applying

If editor styles don't appear correctly:

1. **Ensure Tailwind CSS is installed** in your application with all required directives
2. **Verify Tailwind content paths** include `node_modules/rete-editor` in your `tailwind.config.js`
3. **Import the editor CSS** in your app entry point: `import 'rete-editor/style.css'`
4. **Check dark mode configuration** - your app's Tailwind config should use `darkMode: 'class'`
5. **Rebuild your application** after adding the content path to Tailwind config

### CSS Conflicts with Host Application

The library uses Tailwind utility classes from your application. If you experience layout issues:

1. Make sure you're using a compatible Tailwind CSS version (3.x)
2. Verify your application's Tailwind configuration includes the editor path in `content`
3. Check that both the library and your app use `darkMode: 'class'` (not `'media'`)

## Browser Support

- Chrome/Edge (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)

## Contributing

This is a monorepo package. To contribute or develop locally:

1. Clone the monorepo
2. Install dependencies: `npm install`
3. Build the library: `cd packages/rete-editor && npm run build`
4. Run the demo: `cd packages/demo && npm run dev`

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for version history.

## License

MIT

